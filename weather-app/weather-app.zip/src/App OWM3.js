import React, { Component } from 'react';
import axios from 'axios';
import './App.css';

const API_KEY = "88012a7355abc34f1a146b537516997f";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = { 
      cityName: 'vancouver', 
      cityTemp: '',
      weatherIconURL: ''
    };
    this.fetchImages = this.fetchWeatherData.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  componentDidMount() {
    this.fetchWeatherData();
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.cityName !== this.state.cityName) {
      this.fetchWeatherData();
    }
  }  

  handleChange(e) {
    this.setState({ cityName: e.target.value });
    // this.fetchWeatherData(e.target.value);
  }
  

  fetchWeatherData() {
    axios.get(` https://cors-anywhere.herokuapp.com/https://api.darksky.net/forecast/${API_KEY}/${city}`)
    .then((response) => {
      // handle success
      console.log(response);
      // this.setState({ dogImages: response.data.message });
      let iconURL = response.data.weather[0].icon+'.png';
      this.setState({
        cityTemp: Math.round(response.data.main.temp),
        weatherIconURL: 'http://openweathermap.org/img/w/'+iconURL
      })
    });
  }  
  render() {
    return (
      <div className="App">
        <select value={this.state.cityName} onChange={this.handleChange}>
          <option value="49.282730,-123.120735">Vancouver</option>
          <option value="Edmonton">Edmonton</option>
          <option value="Montreal">Montreal</option>
          <option value="Toronto">Toronto</option>
          <option value="Ottawa">Ottawa</option>
          <option value="Halifax">Halifax</option>
        </select>      
        {/* <h4>new one</h4> */}
        <h4>{this.state.cityName}</h4>
        <h4>{this.state.cityTemp} <img src={this.state.weatherIconURL} alt="icon" /></h4>
      </div>
    );
  }
}

export default App;
