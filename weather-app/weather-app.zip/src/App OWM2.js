import React, { Component } from 'react';
import axios from 'axios';
// import oauth from 'oauth';
import './App.css';

const API_KEY = "c201c235af1ceb169e36850b3a5fac96";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = { 
      cityName: 'vancouver', 
      cityTemp: '',
      weatherIconURL: ''
    };
    this.fetchImages = this.fetchWeatherData.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  componentDidMount() {
    this.fetchWeatherData('vancouver');
  } 

  handleChange(e) {
    this.setState({ cityName: e.target.value });
    this.fetchWeatherData(e.target.value);
  }

  https://api.openweathermap.org/data/2.5/weather?q=vancouver,ca&appid=c201c235af1ceb169e36850b3a5fac96&units=metric&cnt=3&a

  fetchWeatherData(city) {
    axios.get(`http://api.openweathermap.org/data/2.5/weather?q=${city},ca&appid=${API_KEY}&units=metric&cnt=3&a`)
    // GET api.openweathermap.org/data/2.5/forecast?lat=41.4984174&lon=-81.69372869999999&APPID=<your-app-key>
    // GET history.openweathermap.org/data/2.5/find?q=Cleveland&type=accurate&units=metric&mode=xml&start=1483228800&end=1485820800&APPID=<your-app-key>
    // axios.get(`http://api.openweathermap.org/data/2.5/weather?lat=41.4984174&lon=-81.69372869999999&appid=c201c235af1ceb169e36850b3a5fac96&start=1483228800&end=1485820800&units=metric&cnt=3`)
    .then((response) => {
      // handle success
      console.log(response);
      // this.setState({ dogImages: response.data.message });
      let iconURL = response.data.weather[0].icon+'.png';
      this.setState({
        cityTemp: Math.round(response.data.main.temp),
        weatherIconURL: 'http://openweathermap.org/img/w/'+iconURL
      })
    });
  }  
  render() {
    return (
      <div className="App">
        <select value={this.state.cityName} onChange={this.handleChange}>
          <option value="Vancouver">Vancouver</option>
          <option value="Edmonton">Edmonton</option>
          <option value="Montreal">Montreal</option>
          <option value="Toronto">Toronto</option>
          <option value="Ottawa">Ottawa</option>
          <option value="Halifax">Halifax</option>
        </select>      
        {/* <h4>new one</h4> */}
        <h4>{this.state.cityName}</h4>
        <h4>{this.state.cityTemp} <img src={this.state.weatherIconURL} alt="icon" /></h4>
      </div>
    );
  }
}

export default App;
