import React, { Component } from 'react';
import Card from './Card';
import axios from 'axios';
import './App.css';

const API_KEY = "88012a7355abc34f1a146b537516997f";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = { 
      cityCord: '49.282730,-123.120735',
      cityName: 'Vancouver',
      cityTemp: '',
      tempIcon: 'clear-day',
      daily:[]
    };
    this.fetchImages  = this.fetchWeatherData.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.formatTime   = this.formatTime.bind(this);
  }

  componentDidMount() {
    this.fetchWeatherData();
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.cityCord !== this.state.cityCord) {
      this.fetchWeatherData();
    }
  }  

  formatTime() {

    for (let index = 0; index < this.state.daily.length; index++) {
      // const element = array[index];
      
      let formatedTime = new Date(this.state.daily[index].time).getDay();


      this.state.daily[index].time = formatedTime;


      // this.state.daily[index].time = formatedTime.getDay();

      console.log(this.state.daily[index].time);

      // console.log(formatedTime);
      
    }

  }


  // handleIcon(icon) { 
  //   console.log(icon)
  //   this.setState({ tempIcon: 'rain' });
  // } 

  handleChange(e) {
    console.log(e.target.value);
    this.formatTime();
    // console.log( e.target.value);
    // console.log( e.target.value);
   
    // this.setState({ cityLong: e.target.value.long, cityLat: e.target.value.lat, cityName: e.target.value.name });
    this.setState({ cityCord: e.target.value});
    // this.fetchWeatherData(e.target.value);
    // this.handleIcon(this.state.tempIcon);
  }
  

  fetchWeatherData() {
    // let cord = this.state.cityLong + ',' +this.state.cityLat
    axios.get(` https://cors-anywhere.herokuapp.com/https://api.darksky.net/forecast/${API_KEY}/${this.state.cityCord}?&units=ca`)
    .then((response) => {
      // handle success
      console.log(response);
      
      this.setState({ cityName: response.data.timezone , cityTemp: Math.round(response.data.currently.temperature), tempIcon: response.data.currently.icon, daily: response.data.daily.data  });

      console.log(this.state)
      // this.setState({ dogImages: response.data.message });
      // let iconURL = response.data.weather[0].icon+'.png';
      // this.setState({
      //   cityTemp: Math.round(response.data.main.temp),
      //   weatherIconURL: 'http://openweathermap.org/img/w/'+iconURL
      // })
    });
  }  
  render() {

    // for (let index = 0; index < this.state.daily.length; index++) {
    //   var tempo = this.state.daily[index].apparentTemperatureHigh;
    //   // const element = array[index];
    //   // console.log(this.state.daily[index].apparentTemperatureHigh)
    //   // <Card/>  
      
    // }
    // <Card temp={this.state.cityTemp} icon={this.state.tempIcon} />    
    return (
      <div className="App">
        <select value={this.state.cityCord} onChange={this.handleChange}>
          {/* <option value="{cord:49.282730,-123.120735, name:Vancouver }">Vancouver</option>
          <option value="{cord:49.282730,-123.120735, name:soon }">soon</option>
          {/* <option value="{long:53.544388, lat:-113.490929, name:Edmonton }">Edmonton</option>
          <option value="{long:45.501690, lat:-73.567253, name:Montreal }">Montreal</option>
          <option value="{long:43.653225, lat:-79.383186, name:Toronto }">Toronto</option>
          <option value="{long:45.421532, lat:-75.697189, name:Ottawa }">Ottawa</option>
          <option value="{long:44.648766, lat:-63.57523, name:Halifax }">Halifax</option> */} */}
          <option value="49.282730,-123.120735">Vancouver</option>
          <option value="53.544388,-113.490929">Edmonton</option>
          <option value="45.501690,-73.567253">Montreal</option>
          <option value="43.653225,-79.383186">Toronto</option>
          <option value="45.421532,-75.697189">Ottawa</option>
          <option value="44.648766,-63.575237">Halifax</option>
        </select>    

        <ul>
          {this.state.daily.map((city, index) => {
            return (
              // <li key={index}>{city.apparentTemperatureHigh}</li>
              // let day = new Date({city.time});
              <li key={index}> <Card tempH={Math.round(city.apparentTemperatureHigh)} tempL={Math.round(city.apparentTemperatureLow)} summary={city.summary} icon={city.icon} time={city.time}  /></li>
            );
          })}
        </ul>        


        {/* <Card temp={this.city[index].apparentTemperatureHigh} icon={this.city[index].icon}  /> */}
        {/* <li key={fruit + index}>{fruit}</li> */}
        {/* this.state.daily.map(function(city) { */}
            

        {/* <Card temp={this.tempo} icon={this.state.tempIcon} />    */}

        {/* <h4>new one</h4> */}
        {/* <h4>{this.state.cityName}</h4> */}
        {/* <h4>{this.state.cityTemp} <img src={this.state.weatherIconURL} alt="icon" /></h4> */}
        {/* <h4>{this.state.cityTemp}</h4> */}
        {/* <h4>{this.state.tempIcon}</h4> */}

         {/* <WeatherIcon name='darksky' iconId={this.state.tempIcon} flip="horizontal" rotate="90" /> */}
        
      </div>
    );
  }
}

export default App;
