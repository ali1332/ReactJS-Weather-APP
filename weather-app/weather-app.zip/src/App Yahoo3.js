import React, { Component } from 'react';
// import axios from 'axios';
// import oauth from 'oauth';
import './App.css';



class App extends Component {
  constructor(props) {
    super(props);
    this.state = { dogImages: [], selectedBreed: 'poodle' };
    // this.handleChange = this.handleChange.bind(this);
    this.fetchImages = this.fetchWeatherData.bind(this);
  }

  componentDidMount() {
    this.fetchWeatherData();
  }

// https://cors-anywhere.herokuapp.com/


  fetchWeatherData() {
    var OAuth = require('oauth');
    var header = {
        "Yahoo-App-Id": "4SxpFr54",
        "cache-control": "no-cache"
    };

    // var request = new OAuth.OAuth(
    //   'weather-ydn-yql.media.yahoo.com',
    //   '4SxpFr54',
    //   'OAuth',
    //   'dj0yJmk9OXJIQkhHVXZZbVNsJnM9Y29uc3VtZXJzZWNyZXQmc3Y9MCZ4PTJh',
    //   '55c83bde11c8bf92b2a2e35557b480f72bf42b36',
    //   '1.0',
    //   'HMAC-SHA1',
    //   header
    // );

    var request = new OAuth.OAuth({
          Host: "weather-ydn-yql.media.yahoo.com",
          header,
          Authorization: "OAuth",
          oauth_consumer_key:"dj0yJmk9OXJIQkhHVXZZbVNsJnM9Y29uc3VtZXJzZWNyZXQmc3Y9MCZ4PTJh",
          oauth_signature_method:"HMAC-SHA1",
          oauth_timestamp:"",
          oauth_nonce:"",
          oauth_version:"1.0",
          oauth_signature:"YOUR_GENERATED_SIGNATURE"
          
    });
    request.get(
        'https://weather-ydn-yql.media.yahoo.com/forecastrss?location=sunnyvale,ca&format=json',
        null,
        null,
        function (err, data, result) {
            if (err) {
                console.log(err);
            } else {
                console.log(data)
            }
        }
    );
  }  
  render() {
    return (
      <div className="App">
        <h4>new one</h4>
      </div>
    );
  }
}

export default App;
